var Tab = function () {
  // this.tabList = {};
  this.tabList = [];
  this.seeMoreList = {};
  // this.tabArrList = [];
  this.tabIdCounter = 0;
  this.activatedId = null;
  this.dropdownList = null;
}

Tab.prototype.add = function () {
  var username = $('#user-name').val();
  var login = $('#user-login').val();
  // if (this.seeMore()) {
  //   // this.seeMoreList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };
  //   // this.tabListel: $('#see-more-list'), list: this.seeMoreList };
  //   $('#see-more').css('display', 'inline-block');
  // } else {
  //   // this.tabListel: $('#dynamic-tabs'), list: this.tabList };
  //   console.log('sele');
  //   $('#see-more').hide();
  //   // this.tabList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };
  // }
  // this.tabList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };
  this.tabList.push({ tabId: this.tabIdCounter, username: username, login: login, content: username + 'and' + login });
  $('#user-name').val('');
  $('#user-login').val('');
  this.activateTab(this.tabIdCounter);
  this.tabIdCounter++;

  $('.add-transaction').hide();
  $('.tab-body').show();
}

Tab.prototype.findId = function(id) {
  var temp = this.tabList.find(t=>{
    return t.tabId === id
  })
  return temp;
}

Tab.prototype.deleted = function(id) {
  $('[data-id=' + id + ']').remove();
  // delete this.tabList[id];
  var deleteId = this.findId(id);
  console.log('id', deleteId );
  this.tabList.splice(this.tabList.indexOf(deleteId), 1);
  this.render();
}

Tab.prototype.activateTab = function (id) {
  if (false) {
    var curActiveVal = this.tabList[this.activatedId];
    var toSwapVal = this.tabList[id];
    this.tabList[this.activatedId] = toSwapVal;
    this.tabList[id] = curActiveVal;
    // this.tabArrList
  }

  this.activatedId = id;
  this.render();
}

Tab.prototype.render = function () {
  var list = this.tabList;
  var tabBody = $('.tab-body');
  if (this.seeMore()) {
    var el = $('#see-more-tabs');
    el.html('');
    $('#see-more').css('display', 'inline-block');
    // for (let index = this.dropdownList; index < Object.keys(list).length; index++) {
    for (let index = this.dropdownList; index < list.length; index++) {
      processList.call(this, list[index]);
    }
  } else {
    var el = $('#dynamic-tabs');
    el.html('');
    console.log('sele', list);
    $('#see-more').hide();
    // Object.keys(list).forEach(processList.bind(this));
    // list.forEach.bind(this, processList);
    for (let index = 0; index < list.length; index++) {
      processList.call(this, list[index]);
    }
  }

  function processList(t) {
    console.log('loop',t)
    var user = t;
    var activate = this.activatedId === user.tabId ? 'active' : '';
    var template =
      '<div data-id="' + user.tabId + '" class="src-tab ' + activate + '" onclick="tab.activateTab(' + user.tabId + ')">' +
      '<div class="tab-line1">' + user.username + '</div>' +
      '<div class="tab-line2">' + user.login + '</div>' +
      '<i class="material-icons" onclick="tab.deleted(' + user.tabId + ')" >close</i>' +
      '</div>';

    el.append(template);
    if (this.activatedId === user.tabId) {
      tabBody.text(user.content);
    }
  }

}

Tab.prototype.seeMore = function () {
  var tabContWidth = $('.tab-container').width();
  var dynTabsWidth = $('#dynamic-tabs').width();
  var srcTabLength = $('#dynamic-tabs .src-tab').length;
  var seeMoreWidth = $('#see-more').width();
  var fixedTabWidth = $('.fixed-tab').width();
  if ((tabContWidth - fixedTabWidth - seeMoreWidth) < dynTabsWidth) {
    console.log('ggggggg', tabContWidth + " - " + fixedTabWidth + " - " + seeMoreWidth + " < " + dynTabsWidth);
    console.log('xxxxxxxxxxxxxxxxx', srcTabLength);
    this.dropdownList = srcTabLength + 1;
    return true;
  } else {
    return false;
  }
}