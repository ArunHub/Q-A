var Tab = function() {

  // this.tabList = {};

  this.tabList = [];

  this.seeMoreList = {};

  // this.tabArrList = [];

  this.tabIdCounter = 0;

  this.activatedId = null;

  this.ddLen = 0;

}

Tab.prototype.add = function() {

  var username = $('#user-name').val();

  var login = $('#user-login').val();

  // if (this.seeMore()) {

  // // this.seeMoreList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };

  // // this.tabListel: $('#see-more-list'), list: this.seeMoreList };

  // $('#see-more').css('display', 'inline-block');

  // } else {

  // // this.tabListel: $('#dynamic-tabs'), list: this.tabList };

  // console.log('sele');

  // $('#see-more').hide();

  // // this.tabList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };

  // }

  // this.tabList[this.tabIdCounter] = { tabId: this.tabIdCounter, username: username, login: login, content: username + ' and ' + login };

  this.seeMore();

  if (username && login) {

      this.tabList.push({

          tabId: this.tabIdCounter,

          username: username,

          login: login,

          content: username + 'and' + login

      });

      $('#user-name').val('');

      $('#user-login').val('');

      this.activateTab(this.tabIdCounter);

      this.tabIdCounter++;

      $('.add-transaction').hide();

      $('.tab-body').show();

  }

}

Tab.prototype.findId = function(id) {

  var temp = this.tabList.findIndex(t => {

      return t.tabId === id

  })

  return temp;

}

Tab.prototype.deleted = function(id) {

  $('[data-id=' + id + ']').remove();

  // delete this.tabList[id];

  var deleteId = this.findId(id);

  this.tabList.splice(deleteId, 1);

  this.render();

}

Tab.prototype.activateTab = function(id, na) {

  // console.log('na', na);

  if (na === false && na !== undefined) {

      var sid = this.findId(id);

      var cid = this.findId(this.activatedId);

      var curActiveObj = this.tabList[cid];

      var toSwapVal = this.tabList[sid];

      this.tabList[cid] = toSwapVal;

      this.tabList[sid] = curActiveObj;

      console.log('tablist', this.tabList);

      // this.tabArrList

  }

  console.log('id', id);

  console.log('activatedId', this.activatedId);

  this.activatedId = id;

  this.render();

}

Tab.prototype.render = function() {

  var list = this.tabList;

  var tabBody = $('.tab-body');

  var smtEl = $('#see-more-tabs');

  var dtEl = $('#dynamic-tabs');

  smtEl.html('');

  dtEl.html('');

 

        for (let index = 0; index < list.length; index++) {

            var isActive = true;

            if (this.seeMore()) {

                $('#see-more').css('display', 'inline-block');

                isActive = false;

            }

           

          processList.call(this, list[index], index, isActive);

      }

//   if (this.seeMore()) {

//       var el = $('#see-more-tabs');

//       el.html('');

//       $('#see-more').css('display', 'inline-block');

//       // for (let index = this.ddLen; index < Object.keys(list).length; index++) {

//       for (let index = this.ddLen; index < list.length; index++) {

//           processList.call(this, list[index], false);

//       }

//   } else {

//       var el = $('#dynamic-tabs');

//       el.html('');

//       $('#see-more').hide();

//       // Object.keys(list).forEach(processList.bind(this));

//       // list.forEach.bind(this, processList);

//       for (let index = 0; index < list.length; index++) {

//           processList.call(this, list[index], true);

//       }

//   }

 

//   for (let index = 0; index < list.length; index++) {

//     if (index >= this.ddLen) {

       

//         $('#see-more').css('display', 'inline-block');

         

//       }

//     processList.call(this, list[index], true);

// }

 

  function processList(t, idx, na) {

      var user = t;

      var activate = this.activatedId === user.tabId && na ? 'active' : '';

      var template = '<div data-id="' + user.tabId + '" class="src-tab ' + activate + '" onclick="tab.activateTab(' + user.tabId + ', '+na+')">' + '<div class="tab-line1">' + user.username + '</div>' + '<div class="tab-line2">' + user.login + '</div>' + '<i class="material-icons" onclick="tab.deleted(' + user.tabId + ')" >close</i>' + '</div>';

      if (this.seeMore()) {

        smtEl.append(template);

      }else{

        dtEl.append(template);

      }

     

      if (this.activatedId === user.tabId) {

          tabBody.text(user.content);

      }

  }

}

Tab.prototype.seeMore = function() {

  var tabContWidth = $('.tab-container').width();

  var dynTabsWidth = $('#dynamic-tabs').width();

  var srcTabLength = $('#dynamic-tabs .src-tab').length;

  var seeMoreWidth = $('#see-more').width();

  var fixedTabWidth = $('.fixed-tab').width();

  if ((tabContWidth - fixedTabWidth - seeMoreWidth) < dynTabsWidth) {

      // console.log('ggggggg', tabContWidth + " - " + fixedTabWidth + " - " + seeMoreWidth + " < " + dynTabsWidth);

      // console.log('xxxxxxxxxxxxxxxxx', srcTabLength);

      this.ddLen = srcTabLength;

      return true;

  } else {

      return false;

  }

}

 